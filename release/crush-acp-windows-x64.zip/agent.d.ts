import * as acp from "@agentclientprotocol/sdk";
/**
 * CrushAgent implements the ACP Agent interface by wrapping the Crush CLI.
 *
 * This adapter allows Crush to be used from ACP-compatible clients like Zed.
 */
export declare class CrushAgent implements acp.Agent {
    private connection;
    private sessions;
    constructor(connection: acp.AgentSideConnection);
    initialize(params: acp.InitializeRequest): Promise<acp.InitializeResponse>;
    authenticate(params: acp.AuthenticateRequest): Promise<acp.AuthenticateResponse | void>;
    newSession(params: acp.NewSessionRequest): Promise<acp.NewSessionResponse>;
    loadSession(params: acp.LoadSessionRequest): Promise<acp.LoadSessionResponse>;
    setSessionMode(params: acp.SetSessionModeRequest): Promise<acp.SetSessionModeResponse | void>;
    unstable_setSessionModel(params: acp.SetSessionModelRequest): Promise<acp.SetSessionModelResponse | void>;
    prompt(params: acp.PromptRequest): Promise<acp.PromptResponse>;
    cancel(params: acp.CancelNotification): Promise<void>;
    /**
     * Extract text content from the ACP prompt structure
     */
    /**
     * Check if a model supports vision/images
     */
    private isVisionModel;
    /**
     * Extract text content from the ACP prompt structure
     */
    private extractPromptText;
    /**
     * Extract file paths from prompt context (resource links)
     * Filters out image files for non-vision models to prevent errors
     */
    private extractFilePaths;
    /**
     * Run Crush CLI and stream output back to the client
     */
    private runCrush;
    /**
     * Send a tool call update notification
     */
    private sendToolCallUpdate;
    /**
     * Generate a session title from the first prompt
     */
    private generateSessionTitle;
}
//# sourceMappingURL=agent.d.ts.map